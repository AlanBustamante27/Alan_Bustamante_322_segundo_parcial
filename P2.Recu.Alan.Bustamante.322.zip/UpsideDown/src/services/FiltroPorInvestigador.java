package services;

import model.CasoHawkins;

public class FiltroPorInvestigador implements FiltroCasoHawkins {
    
    private String investigador;

    public FiltroPorInvestigador(String investigador) {
        this.investigador = investigador;
    }
    
    
    public boolean filtrar(CasoHawkins caso){
        return caso.getInvestigador().equalsIgnoreCase(investigador);
    }
    
}
