
package services;

import model.CasoHawkins;


public interface FiltroCasoHawkins {
    boolean filtrar(CasoHawkins caso);

}
