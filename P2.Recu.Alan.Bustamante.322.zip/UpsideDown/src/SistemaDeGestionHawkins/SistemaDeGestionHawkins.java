
package SistemaDeGestionHawkins;

import config.RutaArchivos;
import java.io.IOException;
import java.util.Comparator;
import model.CasoHawkins;
import model.ClasificacionCaso;
import persistence.RegistroHawkins;
import persistence.RegistroHawkinsInterface;


public class SistemaDeGestionHawkins {

    public static void main(String[] args) {
    
        try {
            RegistroHawkinsInterface<CasoHawkins> registro = new RegistroHawkins<>();
            registro.agregar(new CasoHawkins(1, "Apertura cerca del laboratorio", "Dr.Brenner", ClasificacionCaso.APERTURA_DIMENSIONAL));
            registro.agregar(new CasoHawkins(2, "Actividad psiquica elevada", "Dr.Owens", ClasificacionCaso.SUJETO_PSIQUICO));
            registro.agregar(new CasoHawkins(3, "Rastros de entidad en Hawkins", "Jim Hopper", ClasificacionCaso.ENTIDAD_HOSTIL));
            registro.agregar(new CasoHawkins(4, "Señales electromagneticas inusuales","Nancy Wheeler", ClasificacionCaso.FENOMENO_ELECTROMAGNETICO));
            registro.agregar(new CasoHawkins(5, "Desaparicion de joven en bosque","Joyce Byers", ClasificacionCaso.DESAPARICION));
            System.out.println("Casos registrados:");
            
            System.out.println("Casos registrados:");
            registro.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCasos tipo SUJETO_PSIQUICO:");
            registro.filtrar(c -> c.getClasificacion() == ClasificacionCaso.SUJETO_PSIQUICO)
                    .forEach(c -> System.out.println(c));

            System.out.println("\nCasos que contienen 'portal':");
            registro.filtrar(c -> c.getTitulo().toLowerCase().contains("portal"))
                    .forEach(c -> System.out.println(c));

            System.out.println("\nCasos ordenados por ID:");
            registro.ordenar((a,b) -> Integer.compare(a.getId(), b.getId()));
            registro.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCasos ordenados por título:");
            registro.ordenar((a,b) -> a.getTitulo().compareToIgnoreCase(b.getTitulo()));
            registro.paraCadaElemento(c -> System.out.println(c));

            registro.guardarEnArchivo(RutaArchivos.getRutaBinString());

            RegistroHawkins<CasoHawkins> cargado = new RegistroHawkins<>();
            cargado.cargarDesdeArchivo(RutaArchivos.getRutaBinString());

            System.out.println("\nCasos cargados desde archivo binario:");
            cargado.paraCadaElemento(c -> System.out.println(c));

            registro.guardarEnCSV(RutaArchivos.getRutaCSVString());

            cargado.cargarDesdeCSV(RutaArchivos.getRutaCSVString(), s -> CasoHawkins.fromCSV(s));

            System.out.println("\nCasos cargados desde archivo CSV:");
            cargado.paraCadaElemento(c -> System.out.println(c));
            } 
            catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
            }
            }
            }

    

