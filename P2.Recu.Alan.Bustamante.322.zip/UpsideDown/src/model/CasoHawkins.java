
package model;

public class CasoHawkins implements Comparable<CasoHawkins>, CSVSerializable {
    private final int id;
    private final String titulo;
    private final String investigador;
    private final ClasificacionCaso clasificacion;

    public CasoHawkins(int id, String titulo, String investigador, ClasificacionCaso clasificacion) {
        this.id = id;
        this.titulo = titulo;
        this.investigador = investigador;
        this.clasificacion = clasificacion;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getInvestigador() {
        return investigador;
    }

    public ClasificacionCaso getClasificacion() {
        return clasificacion;
    }

    @Override
    public int compareTo(CasoHawkins caso){
        return Integer.compare(id, caso.id);
    
    }
    
    public String toCSV(){
        return id + ";" + titulo + ";" + investigador + ";" + clasificacion +"\n";
    } 
    
    public static CasoHawkins fromCSV(String CSV){
        CSV = CSV.replace("\n", "");
        String[] pates = CSV.split(";");
        return new CasoHawkins(Integer.parseInt(pates[0]),pates[1],pates[2],ClasificacionCaso.valueOf(pates[3]));
    }


    @Override
    public String toString() {
        return "CasoHawkins{" + "id=" + id + ", titulo=" + titulo + ", investigador=" + investigador + ", clasificacion=" + clasificacion + '}';
    }
    
    
}
