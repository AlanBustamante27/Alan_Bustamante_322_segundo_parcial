
package persistence;

import java.io.IOException;
import java.io.Serializable;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public interface RegistroHawkinsInterface<T extends Serializable> {
        
    void agregar(T elemento);
    T eliminar(int index);
    T obtener(int index);
    
    List<T> filtrar(Predicate<T> filtro);
    
    void ordenar();
    void ordenar(Comparator<T> cmp);
    
    void paraCadaElemento(Consumer<T> c);
    
    
    void guardarEnArchivo(String path) 
            throws IOException;
    void cargarDesdeArchivo(String path) 
            throws IOException, ClassNotFoundException;

    void guardarEnCSV(String path) 
            throws IOException;
    void cargarDesdeCSV(String path, Function<String,T> creador) 
            throws IOException;
    
}
    
 
   
    

