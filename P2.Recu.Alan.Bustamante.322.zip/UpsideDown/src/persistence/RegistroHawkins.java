
package persistence;

import static config.RutaArchivos.getRutaCSVString;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import model.CasoHawkins;

public class RegistroHawkins<T extends Serializable> implements RegistroHawkinsInterface<T>{
    
    private final List<T> registros = new ArrayList<>();
    
    private CasoHawkins caso;
    
    @Override
    public void agregar(T item){
        Objects.requireNonNull(item, "caso nulo");
        registros.add(item);
    }
    
    @Override
    public T eliminar(int index){
        return registros.remove(index);
    }
    
    @Override
    public T obtener(int index){
        return registros.get(index);
    }

    private List<T> copiarLista(){
        return (new ArrayList<>(registros));
    }
    
    @Override
    public List<T> filtrar(Predicate<T> f) {
        List<T> r = new ArrayList<>();
        for (T t : registros) 
        if (f.test(t)) r.add(t);
        return r;
    }

    @Override
    public void ordenar() {
        Collections.sort((List)registros);
    }

    @Override
    public void ordenar(Comparator<T> cmp) {
        registros.sort(cmp);
    }

    @Override
    public void paraCadaElemento(Consumer<T> c) {
        registros.forEach(c);
    }

    @Override
    public void guardarEnArchivo(String path) throws IOException {
        File carpeta = new File(config.RutaArchivos.BASE);
        if (!carpeta.exists()) carpeta.mkdirs();
        try (ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(path))) {
            o.writeObject(registros);
        }
    }

    @Override
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream o = new ObjectInputStream(new FileInputStream(path))) {
            List<T> cargada = (List<T>) o.readObject();
            registros.clear();
            registros.addAll(cargada);
        }
    }

    @Override
    public void guardarEnCSV(String path) throws IOException {
         File carpeta = new File(config.RutaArchivos.BASE);
         if (!carpeta.exists()) carpeta.mkdirs();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            for (T elem : registros) {
                bw.write(((model.CSVSerializable) elem).toCSV());
                bw.newLine();
            }
        }
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> creador)
            throws IOException {

        registros.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(getRutaCSVString()))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    registros.add(creador.apply(linea));
                }
            }
        }
    }
    
}
