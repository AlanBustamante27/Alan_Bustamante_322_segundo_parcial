
package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface RutaArchivos {

    String BASE = "src/resources/";
    String FILE_CSV = "Caso.csv";
    String FILE_BIN = "Caso.bin";

    static Path getRutaCSV() {
        return Paths.get(BASE, FILE_CSV);
    }

    static Path getRutaBin() {
        return Paths.get(BASE, FILE_BIN);
    }

    static  String getRutaBinString() {
        return getRutaBin().toString();
    }

    static String getRutaCSVString() {
        return getRutaCSV().toString();
    }

}

