
package upsidedown;

import java.io.IOException;
import java.util.Comparator;
import model.CasoHawkins;
import model.ClasificacionCaso;
import model.RegistroHawkins;


public class UpsideDown {

    public static void main(String[] args) {
    
        try {
            RegistroHawkins<CasoHawkins> registro = new RegistroHawkins<>();
            registro.agregar(new CasoHawkins(1, "Apertura cerca del laboratorio", "Dr.Brenner", ClasificacionCaso.APERTURA_DIMENSIONAL));
            registro.agregar(new CasoHawkins(2, "Actividad psíquica elevada", "Dr.Owens", ClasificacionCaso.SUJETO_PSIQUICO));
            registro.agregar(new CasoHawkins(3, "Rastros de entidad en Hawkins", "Jim Hopper", ClasificacionCaso.ENTIDAD_HOSTIL));
            registro.agregar(new CasoHawkins(4, "Señales electromagnéticas inusuales","Nancy Wheeler", ClasificacionCaso.FENOMENO_ELECTROMAGNETICO));
            registro.agregar(new CasoHawkins(5, "Desaparición de joven en bosque","Joyce Byers", ClasificacionCaso.DESAPARICION));
            System.out.println("Casos registrados:");
            registro.paraCadaElemento();
            System.out.println("\nCasos tipo SUJETO_PSIQUICO:");
            registro.filtrar(c -> c.getClasificacion() == ClasificacionCaso.SUJETO_PSIQUICO);
            System.out.println("\nCasos que contienen 'portal':");
            registro.filtrar(c -> c.getTitulo().toLowerCase().contains("portal"))
            .forEach(/* Lambda */);
            System.out.println("\nCasos ordenados por ID:");
            registro.ordenar();
            registro.paraCadaElemento(/* Lambda */);
            System.out.println("\nCasos ordenados por título:");
            registro.ordenar(/* Lambda */);
            registro.guardarEnArchivo("src/data/casos.dat");
            RegistroHawkins<CasoHawkins> cargado = new RegistroHawkins<>();
            cargado.cargarDesdeArchivo("src/data/casos.dat");
            System.out.println("\nCasos cargados desde archivo binario:");
            cargado.paraCadaElemento(/* Lambda */);
            registro.guardarEnCSV("src/data/casos.csv");
            cargado.cargarDesdeCSV("src/data/casos.csv", /* Lambda */);
            System.out.println("\nCasos cargados desde archivo CSV:");
            cargado.paraCadaElemento(/* Lambda */);
            } 
            catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
            }
            }
            }


    
}
