package persistence;

import archivesPath.archivesPath;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import model.CasoHawkins;

public interface CSVSerializable extends Serializable{

    File casoCSV = new File(archivesPath.getRutaCSVString());
    File casoBin = new File(archivesPath.getRutaBinString());

    static void guardarCasosCSV(List<? extends CasoHawkins> lista, String Path) {
        try (BufferedWriter buffer = new BufferedWriter(new FileWriter(casoCSV))) {
            for (CasoHawkins caso : lista) {
                buffer.write(caso.toCSV());
            }

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    static List<CasoHawkins> cargarCasosCSV(String path) {
        try (BufferedReader buffer = new BufferedReader(new FileReader(casoCSV))) {
            String linea;
            List<CasoHawkins> casos = new ArrayList<>();
            while ((linea = buffer.readLine()) != null) {
                casos.add(CasoHawkins.fromCSV(linea));
            }
            return casos;
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        return null;
    }

    static void serializarCasos(List<? extends CasoHawkins> lista, String path) {
        try (ObjectOutputStream archivo = new ObjectOutputStream(new FileOutputStream(casoBin))) {
            archivo.writeObject(lista);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    static List<CasoHawkins> deserializarCasos(String path) {
        List<CasoHawkins> casos = new ArrayList<>();
        try (ObjectInputStream archivo = new ObjectInputStream(new FileInputStream(casoBin))) {
            casos = (List<CasoHawkins>) archivo.readObject();

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        return casos;
    }
}


