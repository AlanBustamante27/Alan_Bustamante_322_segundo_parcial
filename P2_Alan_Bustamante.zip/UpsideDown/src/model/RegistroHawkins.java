
package model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;
import persistence.CSVSerializable;
import services.Almacenable;
import services.FiltroCasoHawkins;

public class RegistroHawkins<T extends CSVSerializable> implements Almacenable<T> {
        
    private final List<T> registros = new ArrayList<>();
    
    @Override
    public void agregar(T item){
        Objects.requireNonNull(item, "caso nulo");
        registros.add(item);
    }
    public boolean eliminar(T item){
        return registros.remove(item);
    }
    
    public T obtener(int indice){
        return registros.get(indice);
    }

    private List<T> copiarLista(){
        return (new ArrayList<>(registros));
    }
    
    @Override
    public Iterator<T> iterator() {
        if (registros.isEmpty() || registros.get(0) instanceof Comparable){
       return iterator((Comparator<T>)Comparator.naturalOrder());
      }
        return copiarLista().iterator();
    }
    
    public Iterator<T> iterator(Comparator<? super T> cmp) {
        return copiaOrdenada(cmp).iterator();
    }

    
    public List<T> copiaOrdenada(Comparator<? super T> cmp) {
        List<T> copia = copiarLista();
        copia.sort(cmp);
        return copia;
    }
    
    

    public static List<CasoHawkins> filtrarPeliculas(List<CasoHawkins> peliculas, FiltroCasoHawkins filtro) {
        List<CasoHawkins> toReturn = new ArrayList<>();
        for (CasoHawkins caso : peliculas) {
            if (filtro.test(caso)) {
                toReturn.add(caso);
            }
        }

        return toReturn;
    }
    
    public void paraCadaElemento(Comparator<? super T> cmp) {
        List<T> copia = copiarLista();
        copia.sort(cmp);
        mostar(copia);

    }
    
    private void mostar(Iterable<T> it) {
        for (T el : it) {
            System.out.println(el);
        }
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public static void ordenar(List<CasoHawkins> casos, Comparator<CasoHawkins> criterio) {
        casos.sort(criterio);
    }
}
    
   
    
 
   
    

