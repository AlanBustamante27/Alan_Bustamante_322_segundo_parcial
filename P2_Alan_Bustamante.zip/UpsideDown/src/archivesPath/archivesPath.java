
package archivesPath;

import java.nio.file.Paths;

public interface archivesPath {

    static final String BASE = "src/resources/";
    static final String FILE_CSV = "Caso.csv";
    static final String FILE_BIN = "Caso.bin";

    static java.nio.file.Path getRutaCSV() {
        return Paths.get(BASE, FILE_CSV);
    }

    static java.nio.file.Path getRutaBin() {
        return Paths.get(BASE, FILE_BIN);
    }

    static  String getRutaBinString() {
        return getRutaBin().toString();
    }

    static String getRutaCSVString() {
        return getRutaCSV().toString();
    }

}

