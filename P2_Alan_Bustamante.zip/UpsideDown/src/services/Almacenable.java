
package services;


import java.util.List;
import java.util.function.Predicate;

public interface Almacenable<T> extends Iterable<T>{
    void agregar(T item);
    boolean eliminar(T item);
    T obtener(int indice);
    List<T> filtrar(Predicate<? super T> criterio);
    
}
