
package services;

import model.CasoHawkins;


public interface FiltroCasoHawkins {
    abstract boolean test(CasoHawkins caso);

}
